%% analyze.m
% Analisis estadistico - Parte II, Laboratorio ADC (Raspberry Pi Pico 2 W)
%
% Requiere, en la misma carpeta, los archivos:
%   samp1.txt ... samp5.txt      -> columnas: Sample, Raw_u16
%   histo1.txt ... histo5.txt    -> columnas: Code12, Count, Voltage_equiv_V
%   (los histo*.txt no se usan en este script; se recalcula todo desde
%    samp*.txt para verificar de forma independiente los resultados de
%    sampling_2.py, tal como pide el punto 5 de la guia)
%
% Genera:
%   - Una figura con 3 subplots por ensayo (Vi vs muestra, histograma en
%     voltios, histograma de codigo de 12 bits), guardada como PNG.
%   - resumen_estadistico.csv con V_media, s [mV], codigos unicos, etc.

clear; clc; close all;

VREF = 3.3;                 % Tension de referencia del ADC [V]
LSB_mV = (VREF/4096)*1000;  % LSB ideal para 12 bits, en mV

nTests = 5;
resultados = table('Size', [nTests 7], ...
    'VariableTypes', {'double','double','double','double','double','double','double'}, ...
    'VariableNames', {'Test','N','Mean_V','Std_mV','N_unique_codes','Code_min','Code_max'});

for i = 1:nTests
    fname = sprintf('samp%d.txt', i);
    T = readtable(fname);              % columnas: Sample, Raw_u16
    raw   = T.Raw_u16;
    muestra = T.Sample;

    % Conversion segun Anexo 1 de la guia
    V      = (raw/65535) * VREF;       % voltaje estimado directo de read_u16()
    code12 = bitshift(raw, -4);        % recupera el codigo original de 12 bits

    meanV   = mean(V);
    stdV_mV = std(V) * 1000;           % desviacion estandar muestral, en mV
    codigosUnicos = numel(unique(code12));
    cmin = min(code12);
    cmax = max(code12);

    resultados.Test(i)            = i;
    resultados.N(i)                = numel(raw);
    resultados.Mean_V(i)           = meanV;
    resultados.Std_mV(i)           = stdV_mV;
    resultados.N_unique_codes(i)   = codigosUnicos;
    resultados.Code_min(i)         = cmin;
    resultados.Code_max(i)         = cmax;

    %% Figura con 3 subplots: serie temporal, histograma en V, histograma de codigo
    fig = figure('Position', [100 100 1500 400], 'Visible', 'off');

    % (a) Vi vs numero de muestra
    subplot(1,3,1);
    plot(muestra, V, 'Color', [0.17 0.42 0.69], 'LineWidth', 0.4);
    hold on;
    yline(meanV, 'r--', sprintf('Media=%.4f V', meanV), 'LineWidth', 1);
    title(sprintf('Test %d: V_i vs muestra', i));
    xlabel('Numero de muestra'); ylabel('Voltaje (V)');
    grid on;

    % (b) Histograma en voltios
    subplot(1,3,2);
    histogram(V, 40, 'FaceColor', [0.22 0.65 0.41], 'EdgeColor', 'k');
    title(sprintf('Test %d: Histograma en voltios', i));
    xlabel('Voltaje (V)'); ylabel('Frecuencia');
    grid on;

    % (c) Histograma de codigo de 12 bits
    subplot(1,3,3);
    edges = cmin:1:(cmax+1);
    histogram(code12, edges, 'FaceColor', [0.84 0.62 0.18], 'EdgeColor', 'k');
    title(sprintf('Test %d: Histograma codigo de 12 bits', i));
    xlabel('Codigo (0-4095)'); ylabel('Frecuencia');
    grid on;

    sgtitle(sprintf('Ensayo %d', i));
    saveas(fig, sprintf('test%d_analysis_matlab.png', i));
    close(fig);
end

disp(resultados);
fprintf('\nLSB ideal (12 bits, Vref=3.3V) = %.4f mV\n', LSB_mV);

writetable(resultados, 'resumen_estadistico_matlab.csv');
