import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

VREF = 3.3
LSB_12 = VREF/4096*1000  # mV

results = []

for i in range(1,6):
    df = pd.read_csv(f"samp{i}.txt")
    df.columns = [c.strip() for c in df.columns]
    raw = df['Raw_u16'].values
    code12 = raw >> 4
    V = raw/65535.0*VREF

    mean_V = V.mean()
    std_V_mV = V.std(ddof=1)*1000
    n_unique_codes = len(np.unique(code12))
    code_min, code_max = code12.min(), code12.max()
    code_range = code_max - code_min

    results.append(dict(test=i, N=len(df), mean_V=mean_V, std_mV=std_V_mV,
                         n_unique_codes=n_unique_codes, code_min=code_min,
                         code_max=code_max, code_range=code_range))

    # Figure with 3 subplots: time series, voltage histogram, code histogram
    fig, axs = plt.subplots(1, 3, figsize=(15,4))

    axs[0].plot(df['Sample'], V, linewidth=0.4, color='#2b6cb0')
    axs[0].set_title(f'Test {i}: V_i vs muestra')
    axs[0].set_xlabel('Número de muestra')
    axs[0].set_ylabel('Voltaje (V)')
    axs[0].axhline(mean_V, color='red', linestyle='--', linewidth=0.8, label=f'Media={mean_V:.4f} V')
    axs[0].legend(fontsize=8)

    axs[1].hist(V, bins=40, color='#38a169', edgecolor='black')
    axs[1].set_title(f'Test {i}: Histograma en voltios')
    axs[1].set_xlabel('Voltaje (V)')
    axs[1].set_ylabel('Frecuencia')

    axs[2].hist(code12, bins=range(code_min, code_max+2), color='#d69e2e', edgecolor='black')
    axs[2].set_title(f'Test {i}: Histograma código de 12 bits')
    axs[2].set_xlabel('Código (0-4095)')
    axs[2].set_ylabel('Frecuencia')

    plt.tight_layout()
    plt.savefig(f'test{i}_analysis.png', dpi=130)
    plt.close()

res_df = pd.DataFrame(results)
res_df.to_csv('resumen_estadistico.csv', index=False)
print(res_df.to_string(index=False))
print(f"\nLSB ideal (12 bits, Vref=3.3V) = {LSB_12:.4f} mV")
